const backendUrl = "http://localhost:5000";

// --------------------
// Views
// --------------------
const loginView = document.getElementById("view-login");
const homeView = document.getElementById("view-initial"); // Fixed ID
const formView = document.getElementById("view-form");

// --------------------
// Login Inputs
// --------------------
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginBtn = document.getElementById("loginBtn");
const loginStatus = document.getElementById("loginStatus");

// --------------------
// Home Buttons
// --------------------
const showFormBtn = document.getElementById("showFormBtn");
const logoutBtn = document.getElementById("logoutBtn");

// --------------------
// Form Inputs
// --------------------
const backBtn = document.getElementById("backBtn");
const roleInput = document.getElementById("role");
const companyInput = document.getElementById("company");
const locationInput = document.getElementById("location");
const statusInput = document.getElementById("statusSelect");
const urlInput = document.getElementById("url");
const notesInput = document.getElementById("notes");
const saveBtn = document.getElementById("saveBtn");
const statusDiv = document.getElementById("status");

// --------------------
// Initial Check
// --------------------
// --------------------
// Initial Check
// --------------------
window.addEventListener("DOMContentLoaded", init);

async function init() {
    const storage = await chrome.storage.local.get("userToken");
    const token = storage.userToken;

    // Strictly ensure the token exists, is a string, and isn't empty or "undefined"
    if (token && typeof token === "string" && token !== "undefined" && token.trim() !== "") {
        showHome();
    } else {
        // Clean up broken storage states
        await chrome.storage.local.remove("userToken");
        showLogin();
    }
}

// --------------------
// View Toggles
// --------------------
function showLogin() {
    loginView.style.display = "block";
    homeView.style.display = "none";
    formView.style.display = "none";
}

function showHome() {
    loginView.style.display = "none";
    homeView.style.display = "block";
    formView.style.display = "none";
}

function showForm() {
    loginView.style.display = "none";
    homeView.style.display = "none";
    formView.style.display = "block";
}

// --------------------
// Login
// --------------------
// --------------------
// Login
// --------------------
// --------------------
// Login
// --------------------
loginBtn.addEventListener("click", async () => {
    loginStatus.innerText = "Logging in...";
    loginStatus.style.color = "#2563eb"; // Blue loading text
    
    try {
        const response = await fetch(`${backendUrl}/api/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: emailInput.value,
                password: passwordInput.value,
            }),
        });

        // Safely parse the backend response
        let data = {};
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
            data = await response.json();
        } else {
            data.message = await response.text();
        }

        // FIX: Check BOTH the HTTP status AND your custom "success" boolean
        if (!response.ok || data.success === false) {
            // data.message catches "invalid credintial" and "uder doesnot exist"
            // data.msg catches your catch(error) block
            loginStatus.innerText = data.message || data.msg || "Login Failed.";
            loginStatus.style.color = "red";
            return;
        }

        // Ensure the server actually handed us a token before logging in
        if (data.token) {
            await chrome.storage.local.set({ userToken: data.token });
            loginStatus.innerText = "";
            emailInput.value = "";
            passwordInput.value = "";
            showHome();
        } else {
            loginStatus.innerText = "Login failed: Server did not return a token.";
            loginStatus.style.color = "red";
        }

    } catch (error) {
        console.error("Login Error:", error);
        loginStatus.innerText = "Cannot connect to server. Is your backend running?";
        loginStatus.style.color = "red";
    }
});

// --------------------
// Logout
// --------------------
logoutBtn.addEventListener("click", async () => {
    await chrome.storage.local.remove("userToken");
    emailInput.value = "";
    passwordInput.value = "";
    showLogin();
});

// --------------------
// Open Form
// --------------------
showFormBtn.addEventListener("click", async () => {
    showForm();
    statusDiv.innerText = "";

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab && tab.url) {
        urlInput.value = tab.url;

        // Skip sending messages to restricted chrome:// pages
        if (tab.url.startsWith("chrome://")) return;

        chrome.tabs.sendMessage(tab.id, { type: "GET_JOB" }, (response) => {
            if (chrome.runtime.lastError || !response) {
                console.log("Could not get job details from page");
                return;
            }

            roleInput.value = response.role || "";
            companyInput.value = response.company || "";
            locationInput.value = response.location || "";
        });
    }
});

// --------------------
// Back
// --------------------
backBtn.addEventListener("click", showHome);

// --------------------
// Save Job
// --------------------
// --------------------
// Save Job
// --------------------

// Helper function to match the URL to a clean Source name
function getSourceName(urlString) {
    if (!urlString) return "Other";
    try {
        const domain = new URL(urlString).hostname.toLowerCase();
        
        if (domain.includes("linkedin")) return "LinkedIn";
        if (domain.includes("indeed")) return "Indeed";
        if (domain.includes("naukri")) return "Naukri";
        if (domain.includes("wellfound") || domain.includes("angel.co")) return "Wellfound";
        if (domain.includes("glassdoor")) return "Glassdoor";
        
        return "Other"; // Fallback for any other website
    } catch (error) {
        return "Other";
    }
}

saveBtn.addEventListener("click", async () => {
    statusDiv.innerText = "";

    const { userToken } = await chrome.storage.local.get("userToken");
    if (!userToken) {
        showLogin();
        return;
    }

    // Use the helper function here!
    const jobData = {
        companyName: companyInput.value.trim(),
        role: roleInput.value.trim(),
        location: locationInput.value.trim(),
        source: getSourceName(urlInput.value), 
        status: statusInput.value,
        jobUrl: urlInput.value,
        notes: notesInput.value,
    };

    if (!jobData.companyName || !jobData.role) {
        statusDiv.innerText = "Company and Role are required.";
        statusDiv.style.color = "red";
        return;
    }

    saveBtn.innerText = "Saving...";

    try {
        const response = await fetch(`${backendUrl}/api/applications/create`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${userToken}`,
            },
            body: JSON.stringify(jobData),
        });

        // Safely parse response
        let data = {};
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
            data = await response.json();
        } else {
            data.message = await response.text();
        }

        // Check for backend errors
        if (!response.ok || data.success === false) {
            statusDiv.innerText = data.message || "Failed to save.";
            statusDiv.style.color = "red";
            saveBtn.innerText = "Save Job";
            return;
        }

        statusDiv.style.color = "green";
        statusDiv.innerText = "Job Saved Successfully.";
        saveBtn.innerText = "Save Job";

        setTimeout(() => {
            showHome();
            roleInput.value = "";
            companyInput.value = "";
            locationInput.value = "";
            notesInput.value = "";
        }, 1200);

    } catch (error) {
        console.error(error);
        statusDiv.innerText = "Server Error.";
        statusDiv.style.color = "red";
        saveBtn.innerText = "Save Job";
    }
});