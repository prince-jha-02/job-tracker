function attachEvents(){

document
.getElementById("closeModal")
.onclick=()=>{

document
.getElementById("jt-overlay")
.remove();

};

document
.getElementById("saveJob")
.onclick=saveJob;

}
async function saveJob(){

const data={

companyName:
document.getElementById("company").value,

role:
document.getElementById("role").value,

location:
document.getElementById("location").value,

status:
document.getElementById("status").value,

jobUrl:
document.getElementById("url").value,

notes:
document.getElementById("notes").value,

source:
window.location.hostname

};

console.log(data);

// Later
// fetch(...)

}
function openJobTrackerModal(){

    if(document.getElementById("jobtracker-modal"))
        return;

    const modal=document.createElement("div");

    modal.id="jobtracker-modal";

    modal.innerHTML=`

<div id="jt-overlay">

<div id="jt-card">

<h2>Add Job</h2>

<input id="company" placeholder="Company"/>

<input id="role" placeholder="Role"/>

<input id="location" placeholder="Location"/>

<select id="status">

<option>Applied</option>
<option>OA</option>
<option>Interview</option>
<option>Offer</option>
<option>Rejected</option>
<option>Ghosted</option>

</select>

<input id="url" placeholder="Job URL"/>

<textarea
id="notes"
placeholder="Notes"
></textarea>

<div class="buttons">

<button id="saveJob">
Save
</button>

<button id="closeModal">
Cancel
</button>

</div>

</div>

</div>

`;

    document.body.innerHTML += `
<div style="
position:fixed;
top:0;
left:0;
width:100%;
height:100%;
background:red;
z-index:999999999;
">
HELLO
</div>`;

    attachEvents();

}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Message Received in Content Script:", request);

    if (request.type === "GET_JOB") {
        // Fallback scraping logic: Grab the page title 
        let scrapedRole = document.title; 
        let scrapedCompany = ""; 
        let scrapedLocation = "";

        sendResponse({
            role: scrapedRole,
            company: scrapedCompany,
            location: scrapedLocation
        });
    }

    // Required for async sendResponse
    return true; 
});